

class Finance {

private:
  float income;
  float tax;
  float essential;
  float extra;

public:
    Finance(float income, float tax, float essential, float extra)
        : income(income), tax(tax), essential(essential), extra(extra) {}

    float getIncome() const {
        return income;
    }

    float getTax() const {
        return tax;
    }

    float getEssential() const {
        return essential;
    }

    float getExtra() const {
        return extra;
    }

};